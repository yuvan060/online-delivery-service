package com.deliveryApplication.zipzap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineDeliveryApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineDeliveryApplication.class, args);
	}

}

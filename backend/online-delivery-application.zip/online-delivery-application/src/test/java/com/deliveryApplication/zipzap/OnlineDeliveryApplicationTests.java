package com.deliveryApplication.zipzap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineDeliveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
